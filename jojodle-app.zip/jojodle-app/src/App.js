import React, { Fragment } from 'react';
import { BrowserRouter as Router, Route, Link, Switch, Routes } from 'react-router-dom';
import GamePageApp from './gamepage/gamepage-component';
import StartPageComponent from './start-page-component';

const App = () => {
  return (
    <Router>
        <Routes>
          {/* <Route exact path='/' element={<StartPageComponent></StartPageComponent>}></Route> */}
          <Route exact path="/" element={<GamePageApp></GamePageApp>} />
        </Routes>
    </Router>
  );
};

export default App;