import React, { useState, useEffect } from 'react';
import standList from './standList';
import './gamepage-component.css';
import ReactSelect from 'react-select';
import md5 from 'md5'
import JojodleLogo from '../media/JOJODLE.png';
import winnerNice from '../media/b3bd434c03d5f766b0fb09ef600013ac.gif';

const GamePageApp = () => {
  const localStandList = standList.stands;
  const [randomStand, setRandomStand] = useState({})
  const [wrongStands, setWrongStands] = useState([]);
  const [isWinner, setIsWinner] = useState(false);
  const parts = [
    "3 - Stardust Crusaders",
    "4 - Diamond is Unbreakable",
    "5 - Golden Wind",
    "6 - Stone Ocean",
    "7 - Steel Ball Run",
    "8 - Jojolion",
  ]

  const sumAsciiValues = str => {
    let total = 0;
    for (let i = 0; i < str.length; i++) {
      total += str.charCodeAt(i);
    }
    return total;
  }

  const seededRandom = () => {
    let today = new Date();
    let formattedDate = today.toLocaleDateString();
    console.log(md5(formattedDate));
    return sumAsciiValues(md5(formattedDate)) % localStandList.length;
  }

  const handleSelectChange = (selected) => {
    if (randomStand.name === selected.label) {
      setIsWinner(true)
    } else {
      setWrongStands([...[localStandList.find(stand => stand.name === selected.label)], ...wrongStands])
    }
  }

  useEffect(() => {
    setRandomStand(localStandList[seededRandom()]);
  }, []);

  const compareArrays = (array1, array2) => {
    return JSON.stringify(array1.slice().sort()) === JSON.stringify(array2.slice().sort());
  }

  const checkPartially = (array1, array2) => {
    return array1.some(item => array2.includes(item));
  }

  const getPartName = part => {
    return parts[part - 3];
  }

  const getDropdownOptionsGrouped = () => {
    let list = [];
    let partCounter = 3;
    parts.forEach(partVar => {
      list.push({
        label: partVar,
        options: localStandList.filter(stand => stand.part === partCounter).map(stand => {
          return { label: stand.name, value: stand.name, image: stand.image }
        })
      })
      partCounter++;
    })
    return list
  }

  return (
    isWinner ? (
      <div className='parent-container-winner'>
        <div className='winner-div'>
          <img src={winnerNice}/>
        </div>
      </div>
    )
      :
      (<div className='parent-container'>
        <div className='centered-div'>
          <table className='contentTable'>
            <tr className='centeredTR'>
              <img className='titleLogo' src={JojodleLogo} />
            </tr>
            <tr className='centeredTR'>
              <div className='selector'>
                <ReactSelect
                  options={getDropdownOptionsGrouped()}
                  onChange={handleSelectChange}
                  formatOptionLabel={stand => (
                    <div className='standContainer'>
                      <img className='standIcon' src={stand.image} alt='' />
                      <label className='standLabel'>{stand.label}</label>
                    </div>
                  )}
                >
                </ReactSelect>
              </div>
            </tr>
            <tr>
              <table className='wrongStandTable'>
                <thead>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Part</th>
                  <th>Name Origin</th>
                  <th>Is user good?</th>
                  <th>Range</th>
                  <th>Shape</th>
                  <th>Type</th>
                  <th>Colors</th>
                </thead>
                {wrongStands.map(stand => (
                  <tr>
                    <td><img className='standIcon' src={stand.image} /></td>
                    <td className='standLabel'>{stand.name}</td>
                    <td className={stand.part === randomStand.part ? 'correctCell' : 'wrongCell'}>{getPartName(stand.part)}</td>
                    <td className={stand.nameOrigin === randomStand.nameOrigin ? 'correctCell' : 'wrongCell'}>{stand.nameOrigin}</td>
                    <td className={stand.isOwnerGood === randomStand.isOwnerGood ? 'correctCell' : 'wrongCell'}>{stand.isOwnerGood ? "Good Guy" : "Villain"}</td>
                    <td className={stand.range === randomStand.range ? 'correctCell' : 'wrongCell'}>{stand.range}</td>
                    <td className={stand.shape === randomStand.shape ? 'correctCell' : 'wrongCell'}>{stand.shape}</td>
                    <td className={compareArrays(stand.type, randomStand.type) ? 'correctCell' : checkPartially(stand.type, randomStand.type) ? 'midCell' : 'wrongCell'}
                    >{stand.type.map(type => (
                      <div>{type}</div>
                    ))}
                    </td>
                    <td className={compareArrays(stand.color, randomStand.color) ? 'correctCell' : checkPartially(stand.color, randomStand.color) ? 'midCell' : 'wrongCell'}
                    >{stand.color.map(color => (
                      <div>{color}</div>
                    ))}
                    </td>
                  </tr>
                ))}
              </table>
            </tr>
          </table>
        </div>
      </div>)
  );
}

export default GamePageApp;
