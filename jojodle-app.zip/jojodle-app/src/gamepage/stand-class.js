class Stand {
    constructor(id, name, part, range, type, colors) {
        this.id = id;
        this.name = name;
        this.part = part;
        this.range = range;
        this.type = type;
        this.colors = colors;
    }
  
    // You can add methods to your class as needed
    evaluate(standToCompare) {
      return false;
    }
  }