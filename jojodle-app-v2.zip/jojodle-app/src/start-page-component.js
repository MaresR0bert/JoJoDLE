import { BrowserRouter as Router, Route, Link, Switch, Routes } from 'react-router-dom';

const StartPageComponent = () => {

    return (
        <ul>
            <li>
                <Link to="/game">Game</Link>
            </li>
      </ul>
    )
}

export default StartPageComponent;