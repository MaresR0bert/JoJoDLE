import starPlatinum from "../media/StarPlatinumMangaAv.png";
import MagicianRedMangaAv from "../media/MagicianRedMangaAv.png";
import TheWorldMangaAv from "../media/TheWorldMangaAv.png";
import HierophantGreen from "../media/HierophantGreenMangaAv.png";
import Hermit from "../media/HermitPurpleMangaAv.png";
import TheFool from "../media/TheFoolMangaAv.png";
import SilverChariot from "../media/SilverChariotMangaAv.png";
import TowerOfGray from "../media/TowerOfGrayMangaAv.png";
import DarkBlueMoonMangaAv from "../media/DarkBlueMoonMangaAv.png";
import Strength from "../media/StrengthMangaAv.png";
import Ebony from "../media/EbonyDevilMangaAv.png";
import YellowTemprence from "../media/YellowTemperanceMangaAv.png";
import HangedManMangaAv from "../media/HangedManMangaAv.png";
import EmperorMangaAv from "../media/EmperorMangaAv.png";
import EmpressMangaAv from "../media/EmpressMangaAv.png";
import WheelOfFortuneMangaAv from "../media/WheelOfFortuneMangaAv.png";
import JusticeMangaAv from "../media/JusticeMangaAv.png";
import LoversMangaAv from "../media/LoversMangaAv.png";
import SunMangaAv from "../media/SunMangaAv.png";
import DeathThirteenMangaAv from "../media/DeathThirteenMangaAv.png"
import JudgementMangaAv from "../media/JudgementMangaAv.png";
import HighPriestessMangaAv from "../media/HighPriestessMangaAv.png";
import GebMangaAv from "../media/GebMangaAv.png";
import KhnumMangaAv from "../media/KhnumMangaAv.png";
import TohthMangaAv from "../media/TohthMangaAv.png";
import AnubisMangaAv from "../media/AnubisMangaAv.png";
import BastetMangaAv from "../media/BastetMangaAv.png";
import SethanMangaAv from "../media/SethanMangaAv.png";
import OsirisMangaAv from "../media/OsirisMangaAv.png";
import HorusMangaAv from "../media/HorusMangaAv.png";
import AtumMangaAv from "../media/AtumMangaAv.png";
import TenoreSaxMangaAv from "../media/TenoreSaxMangaAv.png";
import CreamMangaAv from "../media/CreamMangaAv.png";
import CrazyDiamondMangaAv from "../media/CrazyDiamondMangaAv.png";
import TheHandMangaAv from "../media/TheHandMangaAv.png"
import Echoes from "../media/EchoesAv.gif";
import HeavenDoorMangaAv from "../media/HeavenDoorMangaAv.png";
import KillerQueenMangaAv from "../media/KillerQueenMangaAv.png";
import AquaNecklaceMangaAv from "../media/AquaNecklaceMangaAv.png";
import BadCompanyMangaAv from "../media/BadCompanyMangaAv.png";
import RedHotChiliPepperMangaAv from "../media/RedHotChiliPepperMangaAv.png";
import TheLockMangaAv from "../media/TheLockMangaAv.png";
import SurfaceMangaAv from "../media/SurfaceMangaAv.png";
import LoveDeluxeMangaAv from "../media/LoveDeluxeMangaAv.png";
import PearlJamMangaAv from "../media/PearlJamMangaAv.png";
import AchtungBabyMangaAv from "../media/AchtungBabyMangaAv.png";
import RattMangaAv from "../media/RattMangaAv.png";
import HarvestMangaAv from "../media/HarvestMangaAv.png";
import CinderellaMangaAv from "../media/CinderellaMangaAv.png";
import AtomHeartFatherMangaAv from "../media/AtomHeartFatherMangaAv.png";
import BoyIIManMangaAv from "../media/BoyIIManMangaAv.png";
import EarthWindAndFireMangaAv from "../media/EarthWindAndFireMangaAv.png";
import HighwayStarMangaAv from "../media/HighwayStarMangaAv.png";
import StrayCatMangaAv from "../media/StrayCatMangaAv.png";
import SuperFlyMangaAv from "../media/SuperFlyMangaAv.png";
import EnigmaMangaAv from "../media/EnigmaMangaAv.png";
import CheapTrickMangaAv from "../media/CheapTrickMangaAv.png";
import GoldExperienceAv from "../media/GoldExperienceAv.png";
import StickyFingersAv from "../media/StickyFingersAv.png";
import MoodyBluesAv from "../media/MoodyBluesAv.png";
import SexPistolsAv from "../media/120px-SexPistolsAv.png";
import AerosmithAv from "../media/AerosmithAv.png";
import PurpleHazeAv from "../media/PurpleHazeAv.png";
import SpiceGirlAv from "../media/SpiceGirlAv.png";
import MrPresidentAv from "../media/MrPresidentAv.png";
import KingCrimsonAv from "../media/KingCrimsonAv.png";
import BlackSabbathAv from "../media/BlackSabbathAv.png";
import SoftMachineAv from "../media/SoftMachineAv.png";
import KraftWorkAv from "../media/KraftWorkAv.png";
import LittleFeetAv from "../media/LittleFeetAv.png";
import ManInTheMirrorAv from "../media/ManInTheMirrorAv.png";
import BeachBoyAv from "../media/BeachBoyAv.png";
import TheGratefulDeadAv from "../media/TheGratefulDeadAv.png";
import BabyFaceAv from "../media/120px-BabyFaceAv.gif";
import WhiteAlbumAv from "../media/WhiteAlbumAv.png";
import ClashAv from "../media/ClashAv.png";
import TalkingHeadAv from "../media/TalkingHeadAv.png";
import NotoriousBIGAv from "../media/NotoriousBIGAv.png";
import MetallicaAv from "../media/MetallicaAv.png";
import GreenDayAv from "../media/GreenDayAv.png";
import OasisAv from "../media/OasisAv.png";
import RollingStonesAv from "../media/RollingStonesAv.png";
import StoneFreeAv from "../media/StoneFreeAv.png";
import KissAv from "../media/120px-KissAv.png";
import BurningDowntheHouseAv from "../media/120px-BurningDowntheHouseAv.png";
import FooFightersAv from "../media/120px-FooFightersAv.png";
import WeatherReportSAv from "../media/120px-WeatherReportSAv.png";
import DiverDownAv from "../media/120px-DiverDownAv.png";
import WhitesnakeAv from "../media/WhitesnakeAv.png";
import MOONAv from "../media/C-MOONAv.png";
import MadeinHeavenAv from "../media/MadeinHeavenAv.png";
import GooGooDollsAv from "../media/GooGooDollsAv.png";
import ManhattanTransferAv from "../media/ManhattanTransferAv.png";
import HighwayToHellAv from "../media/HighwayToHellAv.png";
import MarilynMansonAv from "../media/MarilynMansonAv.png";
import JumpinJackFlashAv from "../media/JumpinJackFlashAv.png";
import LimpBizkitAv from "../media/LimpBizkitAv.png";
import SurvivorAv from "../media/SurvivorAv.png";
import PlanetWavesAv from "../media/PlanetWavesAv.png";
import DragonDreamAv from "../media/DragonDreamAv.png";
import YoYoMaAv from "../media/YoYoMaAv.png";
import GrassOfHomeAv from "../media/GrassOfHomeAv.png";
import JailHouseLockAv from "../media/JailHouseLockAv.png";
import BohemianRhapsodyAv from "../media/BohemianRhapsodyAv.png";
import SkyHighAv from "../media/SkyHighAv.png";
import UnderworldAv from "../media/UnderworldAv.png";
import Tusk from "../media/TuskAV.gif";
import BallBreakerAv from "../media/BallBreakerAv.png";
import TicketToRideAv from "../media/TicketToRideAv.png";
import LonesomeMeAv from "../media/LonesomeMeAv.png";
import ScaryMonstersAv from "../media/ScaryMonstersAv.png";
import CreamStarterAv from "../media/CreamStarterAv.png";
import D4CAv from "../media/D4CAv.png";
import InASilentWayAv from "../media/InASilentWayAv.png";
import HeyYaAv from "../media/HeyYaAv.png";
import tombOfTheBoom from "../media/tombOfTheBoom.png";
import RhythmAv from "../media/RhythmAv.png";
import WiredAv from "../media/WiredAv.png";
import MandomAv from "../media/MandomAv.png";
import CatchTheRainbowAv from "../media/CatchTheRainbowAv.png";
import SugarMountainSpringAv from "../media/SugarMountainSpringAv.png";
import TattooYouAv from "../media/TattooYouAv.png";
import TubularBellsAv from "../media/TubularBellsAv.png";
import thCenturyBoyAv from "../media/20thCenturyBoyAv.png";
import CivilWarAv from "../media/CivilWarAv.png";
import ChocolateDiscoAv from "../media/ChocolateDiscoAv.png";
import Soft from "../media/Soft&WetAv.png";
import PaisleyParkAv from "../media/PaisleyParkAv.png";
import DoggyStyleAv from "../media/DoggyStyleAv.png";
import CaliforniaKingBedAv from "../media/CaliforniaKingBedAv.png";
import BornThisWayAv from "../media/BornThisWayAv.png";
import NutKingCallAv from "../media/NutKingCallAv.png";
import PaperMoonKingAv from "../media/PaperMoonKingAv.png";
import KingNothingAv from "../media/KingNothingAv.png";
import SpeedKingAv from "../media/SpeedKingAv.png";
import LoveLoveDeluxeAv from "../media/LoveLoveDeluxeAv.png";
import WalkingHeartAv from "../media/WalkingHeartAv.png";
import SpaceTruckingAv from "../media/SpaceTruckingAv.png";
import Awaking3LeavesAv from "../media/Awaking3LeavesAv.png";
import WonderofUAv from "../media/WonderofUAv.png";
import FunFunFunAv from "../media/FunFunFunAv.png";
import LesFeuillesAv from "../media/LesFeuillesAv.png";
import I_Am_a_Rock_Av from "../media/I_Am_a_Rock_Av.png";
import DoobieWahAv from "../media/DoobieWahAv.png";
import Schottkey1Av from "../media/Schottkey1Av.png";
import Schottkey2Av from "../media/Schottkey2Av.png";
import VitaminCAv from "../media/VitaminCAv.png";
import MilagroManAv from "../media/MilagroManAv.png";
import BlueHawaiiAv from "../media/BlueHawaiiAv.png";
import BrainStormAv from "../media/BrainStormAv.png";
import OzonBabyAv from "../media/OzonBabyAv.png";
import DoctorWuAv from "../media/DoctorWuAv.png";

const StandTypes = {
  FIGHTING: "Fighting",
  COLONY: "Colony",
  PROJECTILE: "Projectile shooting",
  INTEL_GATHERING: "Intelligence gathering",
  PSYCHOLOGICAL_ASSAULT: "Psychological Assault",
  BODY_ALTERATION: "Body Alteration",
  SPACE_TIME_ALTERATION: "Space & Time Alteration",
  WEAPON: "Weapon",
  HIGHLY_CONDITIONAL: "Highly Conditional",
  VICTIM_DEBUFF_BUFF: "Victim Buff or Debuff",
  ELEMENTAL: "Elemental",
  ILLUSION: "Illusion Making",
  TOTAL_DESTRUCTION: "Total Destruction",
  POSITION_CHANGE: "Position changing",
  DEFENSIVE: "Defensive",
  REALITY_BENDING: "Reality Bending",
  ENVIRONMENTAL_CHANGE: "Environmental changing"
}

const Colors = {
  RED: "Red",
  BLUE: "Blue",
  YELLOW: "Yellow",
  GREEN: "Green",
  PURPLE: "Purple",
  ORANGE: "Orange",
  GRAY: "Gray",
  BLACK: "Black",
  WHITE: "White",
  BROWN: "Brown",
  PINK: "Pink",
  COLORLESS: "No specific color",
  EVERCHANGING: "Changes dependent on the case"
}

const standList = {
  "stands": [
    //PART 3
    {
      "name": "Star Platinum",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.PURPLE, Colors.YELLOW],
      "image": starPlatinum
    },
    {
      "name": "Magician's Red",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.PROJECTILE, StandTypes.ELEMENTAL],
      "color": [Colors.RED, Colors.ORANGE],
      "image": MagicianRedMangaAv
    },
    {
      "name": "The World",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.YELLOW],
      "image": TheWorldMangaAv
    },
    {
      "name": "Hierophant Green",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Atrificial Humanoid",
      "type": [StandTypes.PROJECTILE, StandTypes.PSYCHOLOGICAL_ASSAULT],
      "color": [Colors.GREEN],
      "image": HierophantGreen
    },
    {
      "name": "Silver Chariot",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING],
      "color": [Colors.GRAY],
      "image": SilverChariot
    },
    {
      "name": "Hermit Purple",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.INTEL_GATHERING],
      "color": [Colors.PURPLE],
      "image": Hermit
    },
    {
      "name": "The Fool",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.ELEMENTAL, StandTypes.FIGHTING],
      "color": [Colors.GRAY, Colors.YELLOW],
      "image": TheFool
    },
    {
      "name": "Tower of Gray",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.FIGHTING],
      "color": [Colors.GRAY],
      "image": TowerOfGray
    },
    {
      "name": "Dark Blue Moon",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.FIGHTING],
      "color": [Colors.BLUE],
      "image": DarkBlueMoonMangaAv
    },
    {
      "name": "Strength",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.ILLUSION, StandTypes.WEAPON],
      "color": [Colors.GRAY],
      "image": Strength
    },
    {
      "name": "Ebony Devil",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING],
      "color": [Colors.GRAY],
      "image": Ebony
    },
    {
      "name": "Yellow Temprance",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.FIGHTING],
      "color": [Colors.YELLOW],
      "image": YellowTemprence
    },
    {
      "name": "Hanged Man",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.POSITION_CHANGE],
      "color": [Colors.GRAY, Colors.WHITE],
      "image": HangedManMangaAv
    },
    {
      "name": "Emperor",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.PROJECTILE, StandTypes.WEAPON],
      "color": [Colors.GRAY],
      "image": EmperorMangaAv
    },
    {
      "name": "Empress",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.FIGHTING],
      "color": [Colors.RED],
      "image": EmpressMangaAv
    },
    {
      "name": "Wheel of Fortune",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.WEAPON],
      "color": [Colors.GRAY],
      "image": WheelOfFortuneMangaAv
    },
    {
      "name": "Justice",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.ILLUSION],
      "color": [Colors.GRAY],
      "image": JusticeMangaAv
    },
    {
      "name": "Lovers",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.COLONY, StandTypes.FIGHTING],
      "color": [Colors.YELLOW, Colors.ORANGE],
      "image": LoversMangaAv
    },
    {
      "name": "Sun",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.ILLUSION, StandTypes.ELEMENTAL, StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.YELLOW, Colors.ORANGE],
      "image": SunMangaAv
    },
    {
      "name": "Death Thirteen",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.FIGHTING],
      "color": [Colors.WHITE, Colors.BLACK],
      "image": DeathThirteenMangaAv
    },
    {
      "name": "Judgement",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.HIGHLY_CONDITIONAL, StandTypes.PSYCHOLOGICAL_ASSAULT],
      "color": [Colors.YELLOW],
      "image": JudgementMangaAv
    },
    {
      "name": "High Priestess",
      "part": 3,
      "nameOrigin": "Tarot Card",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.ELEMENTAL, StandTypes.FIGHTING],
      "color": [Colors.WHITE, Colors.BROWN],
      "image": HighPriestessMangaAv
    },
    {
      "name": "Geb",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.ELEMENTAL, StandTypes.FIGHTING],
      "color": [Colors.BLUE],
      "image": GebMangaAv
    },
    {
      "name": "Khnum",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.BODY_ALTERATION],
      "color": [Colors.COLORLESS],
      "image": KhnumMangaAv
    },
    {
      "name": "Tohth",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.INTEL_GATHERING],
      "color": [Colors.WHITE, Colors.PURPLE],
      "image": TohthMangaAv
    },
    {
      "name": "Anubis",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.FIGHTING, StandTypes.PSYCHOLOGICAL_ASSAULT],
      "color": [Colors.GRAY, Colors.BLACK],
      "image": AnubisMangaAv
    },
    {
      "name": "Bastet",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.ELEMENTAL, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.WHITE],
      "image": BastetMangaAv
    },
    {
      "name": "Sethan",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.BLACK, Colors.GRAY],
      "image": SethanMangaAv
    },
    {
      "name": "Osiris",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.BLUE],
      "image": OsirisMangaAv
    },
    {
      "name": "Horus",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.PROJECTILE, StandTypes.ELEMENTAL],
      "color": [Colors.BLUE],
      "image": HorusMangaAv
    },
    {
      "name": "Atum",
      "part": 3,
      "nameOrigin": "Egyptian God",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.HIGHLY_CONDITIONAL, StandTypes.INTEL_GATHERING],
      "color": [Colors.BLUE, Colors.WHITE],
      "image": AtumMangaAv
    },
    {
      "name": "Tenore Sax",
      "part": 3,
      "nameOrigin": "Musical Instrument",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.ILLUSION, StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.COLORLESS],
      "image": TenoreSaxMangaAv
    },
    {
      "name": "Cream",
      "part": 3,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.TOTAL_DESTRUCTION],
      "color": [Colors.BLUE, Colors.WHITE],
      "image": CreamMangaAv
    },
    //PART 4
    {
      "name": "Killer Queen",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.TOTAL_DESTRUCTION, StandTypes.FIGHTING, StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.PINK],
      "image": KillerQueenMangaAv
    },
    {
      "name": "Crazy Diamond",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.SPACE_TIME_ALTERATION, StandTypes.FIGHTING],
      "color": [Colors.PINK, Colors.BLUE],
      "image": CrazyDiamondMangaAv
    },
    {
      "name": "The Hand",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.TOTAL_DESTRUCTION, StandTypes.FIGHTING],
      "color": [Colors.BLUE, Colors.WHITE],
      "image": TheHandMangaAv
    },
    {
      "name": "Echoes",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.GREEN, Colors.WHITE],
      "image": Echoes
    },
    {
      "name": "Heaven's Door",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.INTEL_GATHERING],
      "color": [Colors.WHITE],
      "image": HeavenDoorMangaAv
    },
    {
      "name": "Aqua Necklace",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.ELEMENTAL],
      "color": [Colors.BLUE],
      "image": AquaNecklaceMangaAv
    },
    {
      "name": "Bad Company",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.COLONY, StandTypes.PROJECTILE, StandTypes.FIGHTING],
      "color": [Colors.GREEN],
      "image": BadCompanyMangaAv
    },
    {
      "name": "Red Hot Chili Pepper",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.ELEMENTAL, StandTypes.FIGHTING, StandTypes.PROJECTILE],
      "color": [Colors.YELLOW],
      "image": RedHotChiliPepperMangaAv
    },
    {
      "name": "The Lock",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.HIGHLY_CONDITIONAL, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.ORANGE],
      "image": TheLockMangaAv
    },
    {
      "name": "Surface",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.ILLUSION, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.EVERCHANGING, Colors.BROWN],
      "image": SurfaceMangaAv
    },
    {
      "name": "Love Deluxe",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.FIGHTING, StandTypes.WEAPON],
      "color": [Colors.BLACK],
      "image": LoveDeluxeMangaAv
    },
    {
      "name": "Pearl Jam",
      "part": 4,
      "nameOrigin": "Musical Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.COLONY],
      "color": [Colors.RED, Colors.ORANGE],
      "image": PearlJamMangaAv
    },
    {
      "name": "Achtung Baby",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.BODY_ALTERATION],
      "color": [Colors.COLORLESS],
      "image": AchtungBabyMangaAv
    },
    {
      "name": "Ratt",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.PROJECTILE, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.ORANGE, Colors.RED],
      "image": RattMangaAv
    },
    {
      "name": "Harvest",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.COLONY, StandTypes.FIGHTING],
      "color": [Colors.YELLOW, Colors.ORANGE],
      "image": HarvestMangaAv
    },
    {
      "name": "Cinderella",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.PINK],
      "image": CinderellaMangaAv
    },
    {
      "name": "Atom Heart Father",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.COLORLESS],
      "image": AtomHeartFatherMangaAv
    },
    {
      "name": "Boy II Man",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.GRAY],
      "image": BoyIIManMangaAv
    },
    {
      "name": "Earth Wind and Fire",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.BODY_ALTERATION],
      "color": [Colors.EVERCHANGING],
      "image": EarthWindAndFireMangaAv
    },
    {
      "name": "Highway Star",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.INTEL_GATHERING, StandTypes.FIGHTING],
      "color": [Colors.PURPLE, Colors.BLACK],
      "image": HighwayStarMangaAv
    },
    {
      "name": "Stray Cat",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.PROJECTILE, StandTypes.FIGHTING, StandTypes.DEFENSIVE],
      "color": [Colors.BLUE],
      "image": StrayCatMangaAv
    },
    {
      "name": "Super Fly",
      "part": 4,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.GRAY],
      "image": SuperFlyMangaAv
    },
    {
      "name": "Enigma",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.PURPLE],
      "image": EnigmaMangaAv
    },
    {
      "name": "Cheap Trick",
      "part": 4,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.YELLOW],
      "image": CheapTrickMangaAv
    },
    //PART 5
    {
      "name": "Gold Experience",
      "part": 5,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.REALITY_BENDING, StandTypes.FIGHTING],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": GoldExperienceAv
    },
    {
      "name": "Sticky Fingers",
      "part": 5,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.BLUE, Colors.WHITE],
      "image": StickyFingersAv
    },
    {
      "name": "Moody Blues",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.INTEL_GATHERING],
      "color": [Colors.BLUE, Colors.PINK],
      "image": MoodyBluesAv
    },
    {
      "name": "Sex Pistols",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.COLONY, StandTypes.PROJECTILE],
      "color": [Colors.YELLOW],
      "image": SexPistolsAv
    },
    {
      "name": "Aerosmith",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.INTEL_GATHERING, StandTypes.PROJECTILE, StandTypes.FIGHTING],
      "color": [Colors.RED, Colors.BROWN],
      "image": AerosmithAv
    },
    {
      "name": "Purple Haze",
      "part": 5,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.FIGHTING],
      "color": [Colors.PURPLE, Colors.WHITE],
      "image": PurpleHazeAv
    },
    {
      "name": "Spice Girl",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.ELEMENTAL],
      "color": [Colors.PINK, Colors.RED],
      "image": SpiceGirlAv
    },
    {
      "name": "Black Sabbath",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING],
      "color": [Colors.BLACK, Colors.GRAY],
      "image": BlackSabbathAv
    },
    {
      "name": "Soft Machine",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.GRAY, Colors.GREEN],
      "image": SoftMachineAv
    },
    {
      "name": "King Crimson",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.REALITY_BENDING, StandTypes.INTEL_GATHERING, StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.RED, Colors.WHITE],
      "image": KingCrimsonAv
    },
    {
      "name": "Mr. President",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.COLORLESS],
      "image": MrPresidentAv
    },
    {
      "name": "Kraft Work",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.PROJECTILE, StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.GRAY, Colors.GREEN],
      "image": KraftWorkAv
    },
    {
      "name": "Little Feet",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.GRAY, Colors.PURPLE],
      "image": LittleFeetAv
    },
    {
      "name": "Man in the Mirror",
      "part": 5,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.REALITY_BENDING, StandTypes.FIGHTING, StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": ManInTheMirrorAv
    },
    {
      "name": "Beach Boy",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.WEAPON, StandTypes.INTEL_GATHERING, StandTypes.FIGHTING],
      "color": [Colors.GRAY, Colors.ORANGE],
      "image": BeachBoyAv
    },
    {
      "name": "The Greatful Dead",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.GRAY],
      "image": TheGratefulDeadAv
    },
    {
      "name": "Baby Face",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.COLONY],
      "color": [Colors.GRAY],
      "image": BabyFaceAv
    },
    {
      "name": "White Album",
      "part": 5,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.DEFENSIVE, StandTypes.ELEMENTAL],
      "color": [Colors.WHITE],
      "image": WhiteAlbumAv
    },
    {
      "name": "Clash",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.FIGHTING],
      "color": [Colors.GRAY],
      "image": ClashAv
    },
    {
      "name": "Talking Head",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.BODY_ALTERATION, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": TalkingHeadAv
    },
    {
      "name": "Notorious B.I.G",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.HIGHLY_CONDITIONAL, StandTypes.FIGHTING],
      "color": [Colors.RED, Colors.WHITE, Colors.GREEN],
      "image": NotoriousBIGAv
    },
    {
      "name": "Metallica",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.COLONY, StandTypes.ELEMENTAL, StandTypes.FIGHTING],
      "color": [Colors.GRAY],
      "image": MetallicaAv
    },
    {
      "name": "Green Day",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.GREEN],
      "image": GreenDayAv
    },
    {
      "name": "Oasis",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.DEFENSIVE, StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.ORANGE, Colors.YELLOW],
      "image": OasisAv
    },
    {
      "name": "Rolling Stones",
      "part": 5,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.INTEL_GATHERING],
      "color": [Colors.GRAY],
      "image": RollingStonesAv
    },
    //PART 6
    {
      "name": "Stone Free",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.BODY_ALTERATION],
      "color": [Colors.BLUE],
      "image": StoneFreeAv
    },
    {
      "name": "Kiss",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.HIGHLY_CONDITIONAL, StandTypes.REALITY_BENDING],
      "color": [Colors.YELLOW, Colors.RED],
      "image": KissAv
    },
    {
      "name": "Burning Down the House",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.SPACE_TIME_ALTERATION, StandTypes.REALITY_BENDING],
      "color": [Colors.COLORLESS],
      "image": BurningDowntheHouseAv
    },
    {
      "name": "Foo Fighters",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.PROJECTILE],
      "color": [Colors.GRAY, Colors.BLACK],
      "image": FooFightersAv
    },
    {
      "name": "Weather Report",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.ENVIRONMENTAL_CHANGE, StandTypes.ILLUSION],
      "color": [Colors.WHITE],
      "image": WeatherReportSAv
    },
    {
      "name": "Diver Down",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.BLUE, Colors.PURPLE],
      "image": DiverDownAv
    },
    {
      "name": "Whitesnake",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.FIGHTING, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.WHITE, Colors.BLACK],
      "image": WhitesnakeAv
    },
    {
      "name": "C-MOON",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.GREEN, Colors.WHITE],
      "image": MOONAv
    },
    {
      "name": "Made in Heaven",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.REALITY_BENDING, StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.WHITE],
      "image": MadeinHeavenAv
    },
    {
      "name": "Goo Goo Dolls",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.BODY_ALTERATION],
      "color": [Colors.PURPLE],
      "image": GooGooDollsAv
    },
    {
      "name": "Manhattan Transfer",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.INTEL_GATHERING],
      "color": [Colors.BLUE],
      "image": ManhattanTransferAv
    },
    {
      "name": "Highway to Hell",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.PURPLE],
      "image": HighwayToHellAv
    },
    {
      "name": "Marilyn Manson",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.HIGHLY_CONDITIONAL, StandTypes.PSYCHOLOGICAL_ASSAULT],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": MarilynMansonAv
    },
    {
      "name": "Jumpin' Jack Flash",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.PROJECTILE, StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.GRAY, Colors.BLACK],
      "image": JumpinJackFlashAv
    },
    {
      "name": "Limp Bizkit",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.REALITY_BENDING, StandTypes.COLONY],
      "color": [Colors.EVERCHANGING],
      "image": LimpBizkitAv
    },
    {
      "name": "Survivor",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.COLONY],
      "color": [Colors.YELLOW],
      "image": SurvivorAv
    },
    {
      "name": "Planet Waves",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.ELEMENTAL, StandTypes.PROJECTILE],
      "color": [Colors.RED],
      "image": PlanetWavesAv
    },
    {
      "name": "Dragon's Dream",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.INTEL_GATHERING],
      "color": [Colors.GREEN],
      "image": DragonDreamAv
    },
    {
      "name": "Yo-Yo Ma",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.GREEN, Colors.BLUE],
      "image": YoYoMaAv
    },
    {
      "name": "Green, Green Grass of Home",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.BLACK, Colors.GRAY],
      "image": GrassOfHomeAv
    },
    {
      "name": "Jail House Lock",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": JailHouseLockAv
    },
    {
      "name": "Bohemian Rhapsody",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Phenomenon",
      "type": [StandTypes.COLONY, StandTypes.REALITY_BENDING, StandTypes.FIGHTING],
      "color": [Colors.EVERCHANGING],
      "image": BohemianRhapsodyAv
    },
    {
      "name": "Sky High",
      "part": 6,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.COLONY, StandTypes.PROJECTILE],
      "color": [Colors.WHITE, Colors.GREEN],
      "image": SkyHighAv
    },
    {
      "name": "Underworld",
      "part": 6,
      "nameOrigin": "Music Band",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.REALITY_BENDING, StandTypes.ILLUSION],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": UnderworldAv
    },
    //PART 7
    {
      "name": "Tusk",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.PROJECTILE, StandTypes.POSITION_CHANGE, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.PINK],
      "image": Tusk
    },
    {
      "name": "Ball Breaker",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.PROJECTILE, StandTypes.BODY_ALTERATION],
      "color": [Colors.GREEN, Colors.YELLOW],
      "image": BallBreakerAv
    },
    {
      "name": "Ticket to Ride",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.REALITY_BENDING, StandTypes.DEFENSIVE, StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.COLORLESS],
      "image": TicketToRideAv
    },
    {
      "name": "Oh! Lonesome Me",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.WEAPON, StandTypes.BODY_ALTERATION],
      "color": [Colors.BROWN],
      "image": LonesomeMeAv
    },
    {
      "name": "Scary Monsters",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.COLONY, StandTypes.FIGHTING],
      "color": [Colors.COLORLESS],
      "image": ScaryMonstersAv
    },
    {
      "name": "Cream Starter",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.WEAPON, StandTypes.BODY_ALTERATION],
      "color": [Colors.WHITE, Colors.BROWN],
      "image": CreamStarterAv
    },
    {
      "name": "Dirty Deeds Done Dirt Cheap",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.REALITY_BENDING, StandTypes.SPACE_TIME_ALTERATION, StandTypes.FIGHTING],
      "color": [Colors.BLUE, Colors.PINK],
      "image": D4CAv
    },
    {
      "name": "In a Silent Way",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.REALITY_BENDING, StandTypes.PROJECTILE],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": InASilentWayAv
    },
    {
      "name": "Hey Ya!",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.REALITY_BENDING, StandTypes.INTEL_GATHERING],
      "color": [Colors.YELLOW, Colors.BROWN, Colors.GREEN],
      "image": HeyYaAv
    },
    {
      "name": "Tomb of the Boom",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Humanoid",
      "type": [StandTypes.ELEMENTAL, StandTypes.PROJECTILE, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": tombOfTheBoom
    },
    {
      "name": "Boku no Rhythm wo Kiitekure",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.TOTAL_DESTRUCTION, StandTypes.PROJECTILE],
      "color": [Colors.YELLOW, Colors.BROWN, Colors.PINK],
      "image": RhythmAv
    },
    {
      "name": "Wierd",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.WEAPON, StandTypes.PROJECTILE],
      "color": [Colors.GRAY],
      "image": WiredAv
    },
    {
      "name": "Mandom",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.SPACE_TIME_ALTERATION],
      "color": [Colors.PINK, Colors.ORANGE],
      "image": MandomAv
    },
    {
      "name": "Catch the Rainbow",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.ENVIRONMENTAL_CHANGE, StandTypes.PROJECTILE],
      "color": [Colors.WHITE, Colors.BLUE, Colors.RED],
      "image": CatchTheRainbowAv
    },
    {
      "name": "Sugar Mountain",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.REALITY_BENDING, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.YELLOW, Colors.GREEN, Colors.BROWN],
      "image": SugarMountainSpringAv
    },
    {
      "name": "TATOO YOU!",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.POSITION_CHANGE],
      "color": [Colors.WHITE, Colors.GREEN],
      "image": TattooYouAv
    },
    {
      "name": "Tubular Bells",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.INTEL_GATHERING, StandTypes.FIGHTING],
      "color": [Colors.BROWN],
      "image": TubularBellsAv
    },
    {
      "name": "20th Century BOY",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.DEFENSIVE, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.BLUE, Colors.GREEN],
      "image": thCenturyBoyAv
    },
    {
      "name": "Civil War",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.ILLUSION],
      "color": [Colors.YELLOW, Colors.RED],
      "image": CivilWarAv
    },
    {
      "name": "Chocolate Disco",
      "part": 7,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.WEAPON, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": ChocolateDiscoAv
    },
    //PART 8
    {
      "name": "Soft & Wet",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.PROJECTILE, StandTypes.BODY_ALTERATION, StandTypes.REALITY_BENDING],
      "color": [Colors.WHITE, Colors.BLUE],
      "image": Soft
    },
    {
      "name": "Paisley Park",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.INTEL_GATHERING],
      "color": [Colors.PINK, Colors.RED],
      "image": PaisleyParkAv
    },
    {
      "name": "Doggy Style",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.PROJECTILE],
      "color": [Colors.BLUE],
      "image": DoggyStyleAv
    },
    {
      "name": "California King Bed",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.PURPLE, Colors.YELLOW],
      "image": CaliforniaKingBedAv
    },
    {
      "name": "Born This Way",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Phenomenon",
      "type": [StandTypes.HIGHLY_CONDITIONAL, StandTypes.FIGHTING],
      "color": [Colors.BLACK, Colors.GRAY],
      "image": BornThisWayAv
    },
    {
      "name": "Nut King Call",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.PURPLE, Colors.WHITE],
      "image": NutKingCallAv
    },
    {
      "name": "Paper Moon King",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Materialized Object",
      "type": [StandTypes.ILLUSION, StandTypes.PSYCHOLOGICAL_ASSAULT],
      "color": [Colors.WHITE],
      "image": PaperMoonKingAv
    },
    {
      "name": "King Nothing",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Long",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.INTEL_GATHERING],
      "color": [Colors.PINK, Colors.PURPLE],
      "image": KingNothingAv
    },
    {
      "name": "Speed King",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.RED, Colors.ORANGE],
      "image": SpeedKingAv
    },
    {
      "name": "Love Love Deluxe",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": LoveLoveDeluxeAv
    },
    {
      "name": "Walking Heart",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.WEAPON, StandTypes.FIGHTING],
      "color": [Colors.RED],
      "image": WalkingHeartAv
    },
    {
      "name": "Space Trucking",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.SPACE_TIME_ALTERATION, StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.WEAPON],
      "color": [Colors.ORANGE, Colors.RED],
      "image": SpaceTruckingAv
    },
    {
      "name": "Awakening III Leaves",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": true,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.ENVIRONMENTAL_CHANGE, StandTypes.PROJECTILE],
      "color": [Colors.GREEN, Colors.YELLOW],
      "image": Awaking3LeavesAv
    },
    {
      "name": "Wonder of U",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Humanoid",
      "type": [StandTypes.REALITY_BENDING, StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.DEFENSIVE],
      "color": [Colors.BLACK, Colors.YELLOW],
      "image": WonderofUAv
    },
    {
      "name": "Fun Fun Fun",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.HIGHLY_CONDITIONAL, StandTypes.PSYCHOLOGICAL_ASSAULT, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.WHITE],
      "image": FunFunFunAv
    },
    {
      "name": "Les Feuilles",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.COLONY, StandTypes.POSITION_CHANGE],
      "color": [Colors.GREEN],
      "image": LesFeuillesAv
    },
    {
      "name": "I Am a Rock",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Artificial Humanoid",
      "type": [StandTypes.ELEMENTAL, StandTypes.ENVIRONMENTAL_CHANGE, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.RED, Colors.YELLOW],
      "image": I_Am_a_Rock_Av
    },
    {
      "name": "Doobie Wah!",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.FIGHTING, StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.BLUE],
      "image": DoobieWahAv
    },
    {
      "name": "Schott Key No.1",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.POSITION_CHANGE, StandTypes.WEAPON],
      "color": [Colors.GRAY],
      "image": Schottkey1Av
    },
    {
      "name": "Schott Key No.2",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Materialized Object",
      "type": [StandTypes.WEAPON, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.GREEN, Colors.WHITE],
      "image": Schottkey2Av
    },
    {
      "name": "Vitamin C",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.ENVIRONMENTAL_CHANGE, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.GREEN, Colors.YELLOW],
      "image": VitaminCAv
    },
    {
      "name": "Milagro Man",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Phenomenon",
      "type": [StandTypes.VICTIM_DEBUFF_BUFF, StandTypes.HIGHLY_CONDITIONAL],
      "color": [Colors.YELLOW, Colors.BROWN],
      "image": MilagroManAv
    },
    {
      "name": "Blue Hawaii",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.PSYCHOLOGICAL_ASSAULT],
      "color": [Colors.BLUE, Colors.GRAY],
      "image": BlueHawaiiAv
    },
    {
      "name": "Brain Storm",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Natural Non-Humanoid",
      "type": [StandTypes.COLONY, StandTypes.FIGHTING, StandTypes.VICTIM_DEBUFF_BUFF],
      "color": [Colors.BLUE, Colors.PURPLE],
      "image": BrainStormAv
    },
    {
      "name": "Ozon Baby",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Long",
      "shape": "Artificial Non-Humanoid",
      "type": [StandTypes.ENVIRONMENTAL_CHANGE],
      "color": [Colors.GREEN],
      "image": OzonBabyAv
    },
    {
      "name": "Doctor Wu",
      "part": 8,
      "nameOrigin": "Musical Composition",
      "isOwnerGood": false,
      "range": "Close",
      "shape": "Phenomenon",
      "type": [StandTypes.BODY_ALTERATION, StandTypes.FIGHTING],
      "color": [Colors.COLORLESS],
      "image": DoctorWuAv
    },
  ]
}

export default standList