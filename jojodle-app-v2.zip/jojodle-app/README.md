SIMPLE WORDLE CLONE INSPIRED BY JOJO'S BIZZARE ADVENTURE ANIME

NOT TO BE USED FOR ANY COMMERCIAL USE

To run you need:
    - node v22 or later

To start run:
    - npm i
    - npm start